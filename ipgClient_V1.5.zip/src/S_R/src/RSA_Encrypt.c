/*************************************************************************************************************************
				��ȣȭ �� ��ȣȭ�� 1024bit RSA Key�� ������� �Ѵ�.
*************************************************************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>

#include <l_rsa.h>

static void InitRandomStruct(R_RANDOM_STRUCT *);

int RSADecrypt(R_RSA_PRIVATE_KEY PriKey, unsigned char *dstdat, int *dstlen, unsigned char *srcdat, int srclen, int keysize)
{
	int				ret, slen, npos, sourcelen, decblk;
	unsigned char	src[1024], dst[1024];
	unsigned int	dlen;

	npos = *dstlen = 0;
	sourcelen = srclen;

	decblk = (keysize + 7) / 8;

	while( 1 )
	{
		if( srclen >= decblk )
			slen = decblk;
		else
			slen = sourcelen;

		sourcelen -= decblk;

		memset(src, 0x00, sizeof(src)); memset(dst, 0x00, sizeof(dst));
		memcpy(src, srcdat + npos, slen);

		memcpy(src, srcdat + npos, slen);
		if( (ret = RSAPrivateDecrypt(dst, &dlen, src, slen, &PriKey)) )
		{
			fprintf(stderr, "Private Decrypt Error!!\n");
			return 0;
		}

		memcpy(dstdat + (*dstlen), dst, dlen);

		(*dstlen) += dlen;
		npos	  += slen;
		if( sourcelen <= 0 ) break;
	}

	return 1;
}

int RSAEncrypt(R_RSA_PUBLIC_KEY PubKey, unsigned char *dstdat, int *dstlen, unsigned char *srcdat, int srclen, int keysize)
{
	int				encblk, ret, slen, npos, sourcelen;
	unsigned int	dlen;
	unsigned char	src[1024], dst[1204];
	R_RANDOM_STRUCT	randomStruct;

	npos = *dstlen = 0;
	sourcelen = srclen;

	encblk = (keysize + 7) / 8 - 12;

	InitRandomStruct(&randomStruct);

	while( 1 )
	{
		if( sourcelen >= encblk )
			slen = encblk;
		else
			slen = sourcelen;

		sourcelen -= encblk;

		memset(src, 0x00, sizeof(src)); memset(dst, 0x00, sizeof(dst));

		memcpy(src, srcdat + npos, slen);	
		if( (ret = RSAPublicEncrypt(dst, &dlen, src, slen, &PubKey, &randomStruct)) )
		{
			fprintf(stderr, "Public Encrypt Error!!\n");
			return 0;
		}

		memcpy(dstdat + (*dstlen), dst, dlen);

		(*dstlen) += dlen;
		npos	  += slen;
		if( sourcelen <= 0 ) break;
	}

	R_RandomFinal(&randomStruct);

	return 1;
}

static void InitRandomStruct(R_RANDOM_STRUCT *randomStruct)
{
	static unsigned char	seedByte = 0;
	unsigned int 			bytesNeeded;
	int						i;

	R_RandomInit (randomStruct);

	/* Initialize with all zero seed bytes, which will not yield an actual random number output.  */

	while( 1 )
	{
		R_GetRandomBytesNeeded (&bytesNeeded, randomStruct);
		if( bytesNeeded == 0 ) break;

		R_RandomUpdate (randomStruct, &seedByte, 1);
	}

	srandom((unsigned int)time(0L));
	for( i = 0; i < 16; i ++ ) randomStruct->state[i] = random() % 256;
}
