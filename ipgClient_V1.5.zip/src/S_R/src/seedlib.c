#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include <KISA_SEED_ECB.h>
#include <seedlib.h>

int GenerateSeedKeyString(unsigned char *k_str)
{
	int		i, idx;

	idx = 0;
	srand(time(0x00));

	for( i=0; i<10; i++ )
	{
		sprintf((char *)&k_str[idx], "%d", rand());

		if( strlen((char *)k_str) > 16 ) break;
		else    idx = strlen((char *)k_str);
	}

	k_str[16] = 0x00;

	return 1;
}

int JE_SEED_Encrypt(unsigned char *keystring, BYTE *PlainString, DWORD PlnLen, BYTE *CipherString, DWORD *CphLen)
{
	u8	iv[16 ] = {0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};

	u8	cbc[16]												;
	u8	*pos				= (u8 *)CipherString			;
	u32	pdwRoundKey[32]										;

	int	i,j,slen,elen,plen,blocks							;
	
	/* 00. Ű���� */
	SEED_KeySchedKey(pdwRoundKey, keystring);
	
	slen = (int)PlnLen;
	if (slen <= 0) return 0;

	/* 01. pkcs padding �߰� */
	plen = 16 - (slen % 16);

	memcpy(CipherString ,PlainString ,slen);
	for(i=0; i<plen; i++) CipherString[slen+i] = (unsigned char)plen;

	elen = slen + plen;

	/* 02. cbc���� ��ȣȭ */
	blocks = elen / 16;

	memcpy(cbc, iv, 16);
	for (i = 0; i < blocks; i++) {
		for (j = 0; j < 16; j++)
			cbc[j] ^= pos[j];
		
		SEED_Encrypt(cbc,pdwRoundKey);
		memcpy(pos, cbc, 16);
		pos += 16;
	}
	
	(*CphLen) = (DWORD)elen;

	return 1;
}

int JE_SEED_Decrypt(unsigned char *keystring, BYTE *CipherString, DWORD CphLen, BYTE *PlainString, DWORD *PlnLen)
{
	u8	iv[16 ] = {0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};

	u8	cbc[16], tmp[16]									;
	u8	*pos				= (u8 *)PlainString				;
	u32	pdwRoundKey[32]										;

	int	i,j,slen,dlen,plen,blocks							;
	
	/* 00. Ű���� */
	SEED_KeySchedKey(pdwRoundKey, keystring);
	
	slen = (int)CphLen;
	if (slen <= 0 || 0 != slen % 16) return 0;

	memcpy(PlainString ,CipherString ,slen);

	/* 02. cbc���� ��ȣȭ */
	blocks = slen / 16;

	memcpy(cbc, iv, 16);
	for (i = 0; i < blocks; i++) {
		memcpy(tmp, pos, 16);
    
		SEED_Decrypt(pos,pdwRoundKey);
		for (j = 0; j < 16; j++)
			pos[j] ^= cbc[j];
		memcpy(cbc, tmp, 16);
		pos += 16;
	}

	/* 03. pkcs padding ���� */
	dlen = slen;
	plen = (int)PlainString[slen-1];
	if (0 < plen && plen <= 16) /* �е������� �������� ��쿡�� �������� */
	{
		dlen = dlen - plen;
		for(i=0; i<plen; i++) CipherString[slen-i-1] = 0x00;
	}
	
	(*PlnLen) = (DWORD)dlen;

	return 1;
}
