#include <rsa/global.h>
#include <rsa/rsaref.h>
#include <rsa/rsa.h>

typedef struct Certi_Info
{
	char	issue_id[8];			/* �����ڸ�		*/
	char	serial_no[18];			/* �����Ͻ�		*/
	char	expire_date[9];			/* ��������		*/
} CERTI_INFO;

typedef struct Public_Key_Info
{
	CERTI_INFO			CertiInfo;
	R_RSA_PUBLIC_KEY	PublicKey;
} PUBLIC_KEY_INFO;

typedef struct Private_Key_Info
{
	CERTI_INFO			CertiInfo;
	R_RSA_PRIVATE_KEY	PrivateKey;
} PRIVATE_KEY_INFO;

#ifdef	__cplusplus
extern "C"
{
#endif
int RSADecrypt(R_RSA_PRIVATE_KEY, unsigned char *, int *, unsigned char *, int, int);
int RSAEncrypt(R_RSA_PUBLIC_KEY, unsigned char *, int *, unsigned char *, int, int);
#ifdef	__cplusplus
}
#endif
