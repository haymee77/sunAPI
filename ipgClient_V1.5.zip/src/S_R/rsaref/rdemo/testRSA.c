/* RDEMO.C - RSAREF demonstration program
 */

/* Copyright (C) 1991-4 RSA Laboratories, a division of RSA Data
   Security, Inc. All rights reserved.
 */

#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include "global.h"
#include "rsaref.h"

int main PROTO_LIST ((int, char **));
static int SetOptions PROTO_LIST ((int, char **));
static void InitRandomStruct PROTO_LIST ((R_RANDOM_STRUCT *));
static void DoSignFile PROTO_LIST ((void));
static void DoVerifyFile PROTO_LIST ((void));
static void DoSealFile PROTO_LIST ((R_RANDOM_STRUCT *));
static void DoOpenFile PROTO_LIST ((void));
static void DoGenerateKeys PROTO_LIST ((R_RANDOM_STRUCT *));
static void WriteKeypair3 PROTO_LIST ((void));
static void WriteBigInteger PROTO_LIST ((FILE *, unsigned char *, unsigned int));
static int ReadInit PROTO_LIST ((FILE **, char *));
static int ReadUpdate PROTO_LIST ((FILE *, unsigned char *, unsigned int *, unsigned int));
static void ReadFinal PROTO_LIST ((FILE *));
static int ReadBlock PROTO_LIST ((unsigned char *, unsigned int *, unsigned int, char *));
static int WriteInit PROTO_LIST ((FILE **, char *));
static int WriteUpdate PROTO_LIST ((FILE *, unsigned char *, unsigned int));
static void WriteFinal PROTO_LIST ((FILE *));
static int WriteBlock PROTO_LIST ((unsigned char *, unsigned int, char *));
static int GetPublicKey PROTO_LIST ((R_RSA_PUBLIC_KEY **));
static int GetPrivateKey PROTO_LIST ((R_RSA_PRIVATE_KEY **));
static int GetDigestAlgorithm PROTO_LIST ((int *));
static int GetEncryptionAlgorithm PROTO_LIST ((int *));
static void PrintMessage PROTO_LIST ((char *));
static void PrintError PROTO_LIST ((char *, int));
static void GetCommand PROTO_LIST ((char *, unsigned int, char *));

static int SILENT_PROMPT = 0;
extern int errno;

R_RSA_PUBLIC_KEY  RsapubKey1, RsapubKey2, RsapubKey3;
R_RSA_PRIVATE_KEY RsapriKey1, RsapriKey2, RsapriKey3;
int KEYPAIR3_READY = 1;

main(int argc, char **argv)
{
     R_RANDOM_STRUCT randomStruct;
     R_RSA_PROTO_KEY protoKey;
     int done = 0;
     int status, keySize;
     int encSize, decSize;

     int  rfd, wfd;
     int  srclen, dstlen, rtn;
     unsigned char srcdat[4096];
     unsigned char dstdat[4096];

     keySize = 1024;
     encSize = (keySize + 7) / 8 - 12;
     decSize = (keySize + 7) / 8;

     rfd = 0;
     wfd = 0;

     printf("NOTE: before InitRandomStruct() : %d\n", time(0L));
     InitRandomStruct(&randomStruct);
     printf("NOTE: after InitRandomStruct() : %d\n", time(0L));

     printf("NOTE: before GeneratePEMKeys() : %d\n", time(0L));
     protoKey.bits = (unsigned int)keySize;
     protoKey.useFermat4 = 1;
  
     if ( status = R_GeneratePEMKeys(&RsapubKey3, &RsapriKey3, &protoKey, &randomStruct) ) {
          PrintError("generating keys", status);
          return;
     }
     printf("NOTE: after GeneratePEMKeys() : %d\n", time(0L));

     KEYPAIR3_READY = 1;
     WriteKeypair3();

     printf("Keys Generated\n");

     memset(&randomStruct, 0x00, sizeof(R_RANDOM_STRUCT));

     rfd = open("rsasmp.dat", O_RDONLY);
     if ( rfd == -1 )
     {
          printf("rsasmp.dat open error[%d]\n", errno);
          exit(0);
     }
     wfd = open("rsasmp.enc", O_WRONLY|O_CREAT, 0666);
     if ( wfd == -1 )
     {
          printf("rsasmp.enc open error[%d]\n", errno);
          exit(0);
     }
     printf("start encrypt time %d\n", time(0));
     while(1)
     {
          memset(srcdat, 0x00, sizeof srcdat);
          srclen = read(rfd, srcdat, encSize);
          if ( srclen <= 0 ) break;

          rtn = RSAPublicEncrypt(dstdat, &dstlen, srcdat, srclen, &RsapubKey3, &randomStruct);

/*****
printf("encrypt len = %d\n", dstlen);
*****/

          rtn = write(wfd, dstdat, dstlen);
     }
     printf("end encrypt time %d\n", time(0));

     close(rfd);
     close(wfd);

     rfd = open("rsasmp.enc", O_RDONLY);
     if ( rfd == -1 )
     {
          printf("rsasmp.enc open error[%d]\n", errno);
          exit(0);
     }
     wfd = open("rsasmp.dec", O_WRONLY|O_CREAT, 0666);
     if ( wfd == -1 )
     {
          printf("rsasmp.dec open error[%d]\n", errno);
          exit(0);
     }

     printf("start decrypt time %d\n", time(0));
     while(1)
     {
          memset(dstdat, 0x00, sizeof dstdat);
          srclen = read(rfd, srcdat, decSize);
          if ( srclen <= 0 ) break;

     		printf("\tstart decrypt time %d\n", time(0));
          rtn = RSAPrivateDecrypt(dstdat, &dstlen, srcdat, srclen, &RsapriKey3);
     		printf("\tstart decrypt time %d\n", time(0));

          rtn = write(wfd, dstdat, dstlen);
     }
     printf("end decrypt time %d\n", time(0));

     close(rfd);
     close(wfd);

     R_RandomFinal(&randomStruct);
     R_memset((POINTER)&RsapriKey3, 0, sizeof(RsapriKey3));
     return (0);

}

/* Initialize the random structure with all zero seed bytes for test purposes.
   NOTE that this will cause the output of the "random" process to be
     the same every time.  To produce random bytes, the random struct
     needs random seeds!
 */
static void InitRandomStruct(R_RANDOM_STRUCT *randomStruct)
{
     static unsigned char seedByte = 0;
     unsigned int bytesNeeded;
  
     R_RandomInit (randomStruct);
  
     /* Initialize with all zero seed bytes, which will not yield an actual
          random number output.
      */
     while (1) {
          R_GetRandomBytesNeeded (&bytesNeeded, randomStruct);
          if ( bytesNeeded == 0 )
               break;
    
          R_RandomUpdate (randomStruct, &seedByte, 1);
     }
}

static void WriteKeypair3()
{
     FILE *file;
     char filename[256];
  
     while (1) {
          GetCommand(filename, sizeof(filename),"  Enter filename to save the keypair");
          if ( ! *filename )
               return;
    
          if ( filename[0] == '-' && filename[1] == '\0' ) {
               /* use stdout */
               file = stdout;
               break;
          }
          if ( (file = fopen (filename, "w")) != NULL )
               /* successfully opened */
               break;
    
          PrintError ("ERROR: Cannot open a file with that name.  Try again.", 0);
     }

     fprintf (file, "Public Key, %u bits:\n", RsapubKey3.bits);
     fprintf (file, "  modulus: ");
     WriteBigInteger (file, RsapubKey3.modulus, sizeof (RsapubKey3.modulus));
     fprintf (file, "  exponent: ");
     WriteBigInteger (file, RsapubKey3.exponent, sizeof (RsapubKey3.exponent));

     fprintf (file, "\nPrivate Key, %u bits:\n", RsapriKey3.bits);
     fprintf (file, "  modulus: ");
     WriteBigInteger (file, RsapriKey3.modulus, sizeof (RsapriKey3.modulus));
     fprintf (file, "  public exponent: ");
     WriteBigInteger(file, RsapriKey3.publicExponent, sizeof (RsapriKey3.publicExponent));
     fprintf (file, "  exponent: ");
     WriteBigInteger(file, RsapriKey3.exponent, sizeof (RsapriKey3.exponent));
     fprintf (file, "  prime 1: ");
     WriteBigInteger(file, RsapriKey3.prime[0], sizeof (RsapriKey3.prime[0]));
     fprintf (file, "  prime 2: ");
     WriteBigInteger(file, RsapriKey3.prime[1], sizeof (RsapriKey3.prime[1]));
     fprintf (file, "  prime exponent 1: ");
     WriteBigInteger(file, RsapriKey3.primeExponent[0], sizeof(RsapriKey3.primeExponent[0]));
     fprintf (file, "  prime exponent 2: ");
     WriteBigInteger(file, RsapriKey3.primeExponent[1], sizeof(RsapriKey3.primeExponent[1]));
     fprintf (file, "  coefficient: ");
     WriteBigInteger(file, RsapriKey3.coefficient, sizeof (RsapriKey3.coefficient));

     if ( file != stdout )
          fclose (file);
}

/* Write the byte string 'integer' to 'file', skipping over leading zeros. */
static void WriteBigInteger(file, integer, integerLen)
FILE *file;
unsigned char *integer;
unsigned int integerLen;
{
     while (*integer == 0 && integerLen > 0) {
          integer ++;
          integerLen --;
     }
  
     if ( integerLen == 0 ) {
          /* Special case, just print a zero. */
          fprintf (file, "00\n");
          return;
     }
  
     for( ; integerLen > 0; integerLen -- )
          fprintf (file, "%02x ", (unsigned int)(*integer++));

     fprintf (file, "\n");
}

/* Ask for the filename using the given prompt string and open it for reading.
   Return 0 on success or 1 if error or if user cancels by entering a blank.
 */
static int ReadInit (FILE **file, char *prompt) 
{
     char filename[256];
  
     while (1) {
          GetCommand (filename, sizeof (filename), prompt);
          if ( ! *filename )
               return (1);
    
          if ( (*file = fopen (filename, "rb")) != NULL )
               /* successfully opened */
               break;
    
          PrintError("ERROR: Cannot open a file with that name.  Try again.", 0);
     }

     return (0);
}

/* Read a block of up to length maxPartOutLen bytes from file, storing
     it in partOut and returning its length in partOutLen.
   Return 0 on success or 1 if error or end of file.
 */
static int ReadUpdate (file, partOut, partOutLen, maxPartOutLen)
FILE *file;
unsigned char *partOut;
unsigned int *partOutLen;
unsigned int maxPartOutLen;
{
     int status;
  
     /* fread () returns the number of items read in. */
     *partOutLen = fread (partOut, 1, maxPartOutLen, file);

     status = 0;
     if ( ferror (file) ) {
          PrintError ("ERROR: Cannot read file.", 0);
          status = 1;
     }
     if ( *partOutLen == 0 && feof (file) )
          status = 1;

     return (status);
}

/* Close file. */
static void ReadFinal(FILE *file)
{
     fclose(file);
}

/* Read a file of up to length maxBlockLen bytes, storing it in
     block and returning its length in blockLen.
   Ask for the filename using the given prompt string.
   Return 0 on success or 1 if error or if user cancels by entering a blank.
 */
static int ReadBlock (block, blockLen, maxBlockLen, prompt) 
unsigned char *block;
unsigned int *blockLen;
unsigned int maxBlockLen;
char *prompt;
{
     FILE *file;
     int status;
     unsigned char *dummy;
     unsigned int dummyLen;

     if ( ReadInit (&file, prompt) )
          return (1);

     if ( (status = ReadUpdate (file, block, blockLen, maxBlockLen)) == 0 ) {
          if ( *blockLen == maxBlockLen )
               /* Read exactly maxBlockLen bytes, so reading one more will set 
                    end of file if there were exactly maxBlockLen bytes in the file.
                */
               if ( !ReadUpdate (file, dummy, &dummyLen, 1) ) {
                    PrintError ("ERROR: File is too large.", 0);
                    status = 1;
               }
     }
    
     ReadFinal(file);

     return(status);
}

/* Ask for the filename using the given prompt string and open it for writing. 
   Return 0 on success or 1 if error or if user cancels by entering a blank.
 */
static int WriteInit(FILE **file, char *prompt) 
{
     char filename[256];
  
     while (1) {
          GetCommand (filename, sizeof (filename), prompt);
          if ( ! *filename )
               return (1);
    
          if ( filename[0] == '-' && filename[1] == '\0' ) {
               /* use stdout */
               *file = stdout;
               break;
          }
          if ( (*file = fopen (filename, "wb")) != NULL )
               /* successfully opened */
               break;
    
          PrintError("ERROR: Cannot open a file with that name.  Try again.", 0);
     }

     return (0);
}

/* Write block of length partOutLen to a file.
   Return 0 on success or 1 if error. */
static int WriteUpdate(file, partOut, partOutLen)
FILE *file;
unsigned char *partOut;
unsigned int partOutLen;
{
     int status;

     status = 0;
     if ( fwrite (partOut, 1, partOutLen, file) < partOutLen ) {
          PrintError ("ERROR: Cannot write file.", 0);
          status = 1;
     }
  
     return (status);
}

/* Close file.  */
static void WriteFinal(FILE *file)
{
     if ( file != stdout )
          fclose (file);
}

/* Write block of length blockLen to a file.
   Ask for the filename using the given prompt string.
   Return 0 on success or 1 if error or if user cancels by entering a blank.
 */
static int WriteBlock (block, blockLen, prompt) 
unsigned char *block;
unsigned int blockLen;
char *prompt;
{
     FILE *file;
     int status;

     if ( WriteInit(&file, prompt) )
          return (1);

     do {
          if ( (status = WriteUpdate (file, block, blockLen)) != 0 )
               break;
  
          if ( file == stdout )
               /* Printing to screen, so print a new line. */
               printf ("\n");
     } while (0);

     WriteFinal(file);

     return(status);
}

static void PrintMessage(char *message)
{
     if (!SILENT_PROMPT) {
          puts(message);
          fflush(stdout);
     }
}

/* If type is zero, simply print the task string, otherwise convert the
     type to a string and print task and type.  */
static void PrintError(char *task, int type)
{
     char *typeString, buf[80];

     if ( type == 0 ) {
          puts (task);
          return;
     }
  
     /* Convert the type to a string if it is recognized. */
     switch (type) {
     case RE_KEY:
          typeString = "Recovered DES key cannot decrypt encrypted content";
          break;
     case RE_LEN:
          typeString = "Encrypted key length or signature length is out of range";
          break;
     case RE_MODULUS_LEN:
          typeString = "Modulus length is out of range";
          break;
     case RE_PRIVATE_KEY:
          typeString = "Private key cannot encrypt message digest, or cannot decrypt encrypted key";
          break;
     case RE_PUBLIC_KEY:
          typeString = "Public key cannot encrypt data encryption key, or cannot decrypt signature";
          break;
     case RE_SIGNATURE:
          typeString = "Signature is incorrect";
          break;
    
     default:
          sprintf (buf, "Code 0x%04x", type);
          typeString = buf;
     }

     printf("ERROR: %s while %s\n", typeString, task);  
     fflush(stdout);
}

static void GetCommand(command, maxCommandSize, prompt)
char *command;
unsigned int maxCommandSize;
char *prompt;
{
     unsigned int i;
  
     if ( !SILENT_PROMPT ) {
          printf ("%s (blank to cancel): \n", prompt);  
          fflush (stdout);
     }

     fgets (command, maxCommandSize, stdin);
  
     /* Replace the line terminator with a '\0'. */
     for (i = 0; command[i] != '\0'; i++) {
          if ( command[i] == '\012' || command[i] == '\015' || i == (maxCommandSize - 1) ) {
               command[i] = '\0';
               return;
          }
     }
}

