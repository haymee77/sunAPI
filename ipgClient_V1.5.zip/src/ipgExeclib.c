#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdarg.h>
#include <errno.h>
#include <time.h>
#include <sys/time.h>
#include <fcntl.h>
#include <string.h>

#include <l_rsa.h>
#include <seedlib.h>
#include <ipgExeclib.h>

#define	YYYYMMDD	        1
#define	HHMMSS		        2
#define	YYYYMMDDhhmmss		3

#define CHAR_SIZE 1024*16
#define MSG_TIMEOUT   12
#define CON_TIMEOUT   3

unsigned char	SeedKeyString[32];
char			P_Addr[16];
int             P_Port;  
int             CliSockfd;  
char            decryptflag;

int             ServiceLen;

char            client_ip[20] ;
int             client_port ;

time_t          init_time;

PUBLIC_KEY_INFO     PubKey =
{
	{
		{
		0x4b,0x53,0x4e,0x45,0x54,0x2d,0x4c,0x00
		},
		{
		0x4c,0x2d,0x32,0x30,0x30,0x32,0x30,0x35,0x32,0x30,
		0x3a,0x31,0x30,0x30,0x32,0x35,0x38,0x00
		},
		{
		0x32,0x31,0x30,0x30,0x30,0x31,0x30,0x31,0x00
		}
	},
	{
		1024,
		{
		0xd4,0x84,0x6c,0x2b,0x82,0x28,0xdd,0xdf,0xab,0x9e,
		0x61,0x4d,0xa2,0xa3,0x24,0xc1,0xcc,0x7b,0x29,0xd8,
		0x48,0xcc,0x00,0x56,0x24,0xd3,0xa0,0x96,0x67,0xa2,
		0xaa,0xb9,0x07,0x32,0x90,0xba,0xce,0x6a,0xa5,0x36,
		0xdd,0xce,0xb3,0xc4,0x7d,0xdd,0xa7,0x8d,0x99,0x54,
		0xda,0x06,0xc8,0x3a,0xa6,0x5b,0x93,0x9c,0x5e,0xc7,
		0x73,0xa3,0x78,0x7e,0x71,0xbe,0xc5,0xa1,0xc0,0x77,
		0xbb,0x44,0x6c,0x06,0xb3,0x93,0xd2,0x53,0x79,0x67,
		0x64,0x5d,0x38,0x6b,0x4b,0x0b,0x4e,0xc2,0x13,0x72,
		0xfd,0xc7,0x28,0xc5,0x66,0x93,0x02,0x8c,0x1c,0x39,
		0x15,0xc1,0xc4,0x27,0x97,0x93,0xeb,0x3d,0xcc,0xef,
		0xd6,0xbf,0x49,0xb8,0x6c,0xc7,0xd8,0x8a,0x47,0xb0,
		0xd4,0x4a,0xba,0x9e,0x73,0x75,0x0f,0xcd
		},
		{
		0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
		0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
		0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
		0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
		0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
		0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
		0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
		0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
		0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
		0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
		0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
		0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
		0x00,0x00,0x00,0x00,0x00,0x01,0x00,0x01
		}
	}
};

int ConnectServer(char *, int);
int Write_Line(int, char *, int);
int Read_Line(int, char *, int);

int SendMsgToIpgServer(int, int, char *);
int RecvMsgFromIpgServer(int, int*, char *);

void GetCurrentDate(char *, int);

void WriteLog(const char *fmt, ... );

/* RecvBuf[0] = ��ȣȭ���� �ʵ� (2:��ȣȭ , 0:��ȣȭ ����.) */
/* JSP�� CGI�� ���� ��û ������ �д´�. */
int RecvMsg(int *rlen, char *RecvBuf)
{
	int		len;
	char	buf[32];
	
	memset(buf, 0x00, sizeof(buf));
	if( Read_Line(CliSockfd, buf, ServiceLen) < 0 ) return -1;

	if( (len = atoi(buf)) <= 0 || len > 10000)
	{
		WriteLog("Error : Recv Length is a negative num, len = %d\n", len);
		return -1;
	}

	if( Read_Line(CliSockfd, RecvBuf, len) < 0 ) return -1;
	
	if(RecvBuf[0] == '1')
	{
		RecvBuf[0] = '2';
	}else
	if( RecvBuf[0] != '2' && RecvBuf[0] != '3' ){
		RecvBuf[0] = '0';
	}
	
	decryptflag = RecvBuf[0];
	*rlen = len;

	return 1;
}

/* ����� JSP�� CGI�� ������. */
int WriteMsg(int wlen, char *SendBuf)
{
	int     len;
	char	buf[CHAR_SIZE];

	len = 0;
	memset(buf, 0x00, sizeof(buf));
	sprintf(buf ,"%.*d" ,ServiceLen ,wlen) ; len = len + ServiceLen;
	memcpy(&buf[ServiceLen] ,SendBuf ,wlen); len = len + wlen;

	if( Write_Line(CliSockfd, buf, len) < 0 ) return -1;

	return 1;
}

/* ���� ��û�� KSNet IPGServer�� ������, �� ����� �޴´�. */
int RequestApproval(int clen, char *cliMsg, int *rlen, char *RecvMsg)
{
	int		sockfd = -1;
	int     i, step = 0, secs[3] = {0,0,0};
	time_t  ctime, stime, ptime;
	
	char LoggingBuf[CHAR_SIZE];
	
	time(&ctime);
	ptime = stime = ctime;
		
	for(i=0; i<2; i++)
	{
		alarm(CON_TIMEOUT);
		sockfd = ConnectServer(P_Addr, P_Port);
		alarm(0);		
		if (sockfd>0) break;
	}
	
	if (i == 2) return -1;
	
	time(&ctime);
	secs[step] = ctime - ptime; ptime = ctime;
	step++;
	
	/* �α� ��� �� ī���ȣ/��ȿ�Ⱓ ����ŷ ó�� */
	memset(LoggingBuf, 0x00, sizeof(LoggingBuf));
	memcpy(LoggingBuf, cliMsg, clen);
	maskingCardNo(LoggingBuf);
	
	alarm(MSG_TIMEOUT);
	/*��û�����α�*/
	WriteLog("[%s:%d->%s:%d] >> T(%02d)(%d:_:_) SendMessage=(%d:%s)\n", client_ip, client_port,P_Addr, P_Port, (ctime-init_time), secs[0], clen, LoggingBuf) ;
	
	if( SendMsgToIpgServer(sockfd, clen, cliMsg) < 0 )
	{
		goto ERR_END;
	}
	time(&ctime);
	secs[step] = ctime - ptime; ptime = ctime;
	step++;

	memset(RecvMsg, 0x00, sizeof(RecvMsg));
	if( RecvMsgFromIpgServer(sockfd, rlen, RecvMsg) < 0 )
	{
		goto ERR_END;
	}
	time(&ctime);
	secs[step] = ctime - ptime; ptime = ctime;
	step++;
	
	/* �α� ��� �� ī���ȣ/��ȿ�Ⱓ ����ŷ ó�� */
	memset(LoggingBuf, 0x00, sizeof(LoggingBuf));
	memcpy(LoggingBuf, RecvMsg, (*rlen));
	maskingCardNo(LoggingBuf);
	
	alarm(0);
	/*���������α�*/
	WriteLog("[%s:%d<-%s:%d] >> T(%02d)(%d:%d:%d) RecvMessage=(%d:%s)\n", client_ip, client_port,P_Addr, P_Port, (ctime-init_time), secs[0], secs[1],secs[2], (*rlen), LoggingBuf) ;
	
	close(sockfd);
	return 1;
	
	ERR_END:
	alarm(0);	
	time(&ctime);
	secs[step] = ctime - ptime; ptime = ctime;
	WriteLog("[%s:%d<-%s:%d] >> T(%02d)(%d:%d:%d) ERROR_STEP(%d) MSG(%d:%s)\n", client_ip, client_port,P_Addr, P_Port, (ctime-init_time),secs[0],secs[1],secs[2], step, clen,cliMsg) ;

	close(sockfd);
	return (-1 * (step+1));
}

/* ipgServer�� ������ ������.(�ʿ��ϸ� ��ȣȭ) */
int SendMsgToIpgServer(int sockfd, int clen, char *cliMsg)
{
	char            SendBuf[CHAR_SIZE], buf[32];
	int             tlen=0, len=0 ,idx=0;
	
	if ('0' == decryptflag)
	{
		sprintf(&SendBuf[idx] ,"%.*d" ,ServiceLen ,clen)                     ; idx = idx + ServiceLen;
		memcpy(&SendBuf[idx] ,cliMsg ,clen)                                  ; idx = idx + clen;
	}else
	{
		/* 00. 1ȸ�� seed key�� ���Ѵ�. */
		memset(SeedKeyString ,0x00 ,sizeof(SeedKeyString));
		GenerateSeedKeyString(SeedKeyString);/* 16byte�� session key�� �����Ѵ�. */

    	/* 01.��ȣȭ Ű������ ���� : ���� + ��ȣȭ���� + (��ȣȭ��)Ű */
    	if( decryptflag == '2') /* ��ȣȭ�� �ʿ��ϴ�.(RSA-SEED) */
    	{
    	    if( !RSAEncrypt(PubKey.PublicKey, (unsigned char *)&SendBuf[idx+ServiceLen+1], &tlen, (unsigned char *)SeedKeyString, 16, 1024) ) /* seedkey�� rsa�� ��ȣȭ�� �������� �ڿ� ���� */
    	    {
    	        WriteLog("Error : Session key ��ȣȭ(RSA) ����!!\n");
    	        return -1;
    	    }

			sprintf(buf ,"%.*d%c" ,ServiceLen ,tlen+1 ,decryptflag)          ;
			memcpy(&SendBuf[idx] ,buf ,ServiceLen+1)                         ; idx = idx + ServiceLen + 1;
			/* RSAEncrypt���� &SendBuf[idx+ServiceLen+1]  */                 ; idx = idx + tlen;
    	}else
    	if( decryptflag == '3') /* ��ȣȭ�� �ʿ��ϴ�.(SEED) */
    	{
    	    tlen = 16;
    	    sprintf(&SendBuf[idx] ,"%.*d%c" ,ServiceLen ,tlen+1 ,decryptflag); idx = idx + ServiceLen + 1;
    	    memcpy(&SendBuf[idx] ,SeedKeyString ,tlen)                       ; idx = idx + tlen;
    	}else
    	{
    		WriteLog("Error : ��ȣȭ �κ�(%c)����!!\n" ,decryptflag);
    		return -1;
    	}

		/* 02.��ȣȭŰ�� ������ ��ȣȭ : ���� + ��ȣȭ(��ȣȭ��������...) */
		if( !JE_SEED_Encrypt(SeedKeyString, (BYTE *)cliMsg, (DWORD)clen, (BYTE *)&SendBuf[idx+ServiceLen], (DWORD *)&tlen) )
		{
			WriteLog("Error : SEED ��ȣȭ ����\n");
			return -1;
		}    
		
		sprintf(buf ,"%.*d" ,ServiceLen ,tlen);
		memcpy(&SendBuf[idx] ,buf ,ServiceLen)              ; idx = idx + ServiceLen;
		/* JE_SEED_Encrypt���� &SendBuf[idx+ServiceLen]  */ ; idx = idx + tlen;
	}
	len = idx;
	
	if( Write_Line(sockfd, SendBuf, len) < 0 ) return -1;

	return 1;
}

/* ipgServer�� ���� ������ �д´�.(�ʿ��ϸ� ��ȣȭ) */
int RecvMsgFromIpgServer(int sockfd, int *rlen ,char *RecvBuf)
{
	char	TempBuf[CHAR_SIZE],TempBuf1[CHAR_SIZE];
	int		len1, len2,len;

	memset(TempBuf, 0x00, sizeof(TempBuf));
	memset(TempBuf1, 0x00, sizeof(TempBuf1));
	
	if( Read_Line(sockfd, TempBuf, ServiceLen) < 0 ) return -1;

	len1 = atoi(TempBuf);
	
	memset(TempBuf, 0x00, sizeof(TempBuf));
	if( Read_Line(sockfd, TempBuf, len1) < 0 ) return -1;

	if( decryptflag == '2' || decryptflag == '3')
	{ 
		if( !JE_SEED_Decrypt(SeedKeyString, (BYTE *)TempBuf, (DWORD)len1, (BYTE *)RecvBuf, (DWORD *)&len2) )
		{
			WriteLog("Error : SEED ��ȣȭ ����\n");
			return -1;
		} 
		(*rlen) = len2;
	}
	else
	{
		memcpy(RecvBuf, TempBuf, len1);
		(*rlen) = len1;
	}

	return 1;
}
 
int InitialEnv(int argc, char **argv)
{
	int  idx;
	char *ptr ,buff[8];

	if( argc != 5 )
	{
		WriteLog("This program can not execute on shell!!\n");
		exit(1);
	}
		
	CliSockfd = atoi(argv[1]);
	
	memset(P_Addr, 0x00, sizeof(P_Addr)); 
	strcpy(P_Addr, argv[2]); 

	P_Port = atoi(argv[3]);
	
	if(strncmp(argv[4],"KTF",3) == 0 || strncmp(argv[4],"6",1) == 0)		
		ServiceLen = 6;
	else if(strncmp(argv[4],"KSPAY",5) == 0 || strncmp(argv[4],"4",1) == 0 )	
		ServiceLen = 4;

	time(&init_time);
	
	return 1;
}

int ConnectServer(char *IpAddr, int Port)
{
	int					sockfd, i, len;
	struct linger		ling;
	struct sockaddr_in	addr, client_info ;
	
	if( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		WriteLog(">>> Socket Open Error (%d:%s)\n", errno ,strerror(errno));
		return -1;
	}
	
	bzero(&addr, sizeof(addr));
	addr.sin_family      = AF_INET;
	addr.sin_addr.s_addr = inet_addr(IpAddr);;
	addr.sin_port        = htons(Port);
	
	if( connect(sockfd, (struct sockaddr *)&addr, sizeof(addr)) < 0 )
	{
		WriteLog(">>> Connect(%s:%d) Error (%d:%s)\n", IpAddr, Port, errno , strerror(errno));
		close(sockfd);
		return -1;
	}
	
	ling.l_onoff  = 1;
	ling.l_linger = 0;
	if (setsockopt(sockfd, SOL_SOCKET, SO_LINGER, (char*)&ling, sizeof(ling)) < 0)
	{
		WriteLog(">>> Connect(%s:%d) setsockopt Error (%d:%s)\n", IpAddr, Port, errno , strerror(errno));
		close(sockfd);
		return -1;
	}

	memset(&client_info, 0x00, sizeof(client_info)) ;
	len = sizeof(client_info) ;
	if (getsockname(sockfd, (struct sockaddr *)&client_info, (socklen_t *)&len) < 0)
	{
		WriteLog(">>> Connect(%s:%d) getsockname Error (%d:%s)\n", IpAddr, Port, errno , strerror(errno));
		close(sockfd);
		return -1;
	}

#if 0
	memset(client_ip, 0x00, sizeof(client_ip)) ;
	sprintf(client_ip, "%s", inet_ntoa(client_info.sin_addr)) ;
#endif
	if (!inet_ntop(AF_INET ,&(client_info.sin_addr ) ,client_ip ,sizeof(client_ip)))
	{
		printf(">>> Connect(%s:%d) inet_ntop Error(%d:%s)\n", IpAddr, Port,errno ,strerror(errno));
		close(sockfd);
		return -1;
	}

	client_port = ntohs(client_info.sin_port) ;

	return sockfd;  
}

int Write_Line(int fd, char *sendbuf, int len)
{
	int i;
	int	slen, wlen, spt = 0;
	
	slen = len;

	for(i=0; i<10;i++)
	{
		if( (wlen = write(fd, &sendbuf[spt], slen)) < 0 )
		{
			WriteLog(">>> write(send) Error (%d:%s)\n", errno, strerror(errno));
			return -1;
		}

		slen = slen - wlen;
		spt = spt + wlen;

		if( slen == 0 ) return 1;
	}
	
	WriteLog(">>> write(send) failed retry(%d) left-len(%d/%d)\n", i,slen,len);
/*
	fprintf(stdout, "Send_Data -> [%s]\n", sendbuf);
*/
	return -1;	
}

#if 0
int Read_Line(int fd, char *recvbuf, int len)
{
    int				i,cnt;
    int             restlen, readlen, rtnlen;
    
#if 1
    fd_set          fds;

    struct timeval  tv;

    tv.tv_sec = 2;
    tv.tv_usec = 0;
#endif

    restlen = len;
    readlen = 0;

    for(i=0; i<10; i++)
    {
	    FD_ZERO(&fds);
    	FD_SET(fd, &fds);
#if 1
        if( (cnt = select(fd + 1, &fds, NULL, NULL, &tv)) == 0 )
        {
        	continue;
        }
        
        if (cnt < 0)
        {
            WriteLog(">>> select Error (%d:%s)\n", errno, strerror(errno));
            return -1;
        }
#endif
        if( (rtnlen = read(fd, &recvbuf[readlen], restlen)) < 0 )
        {
            WriteLog(">>> read(recv) Error (%d:%s)\n", errno, strerror(errno));
            return -1;
        }
        
        if( rtnlen == 0 )
        {
            WriteLog(">>> read(recv) socket closed!!\n");
            return -1;
        }

        readlen = readlen + rtnlen;
        restlen = restlen - rtnlen;

        if( restlen == 0 ) return 1;
    }
    
    WriteLog(">>> read(recv) failed retry(%d) left-len(%d/%d)\n", i,restlen,len);
/*
    fprintf(stdout, "Recv_Data -> [%s]\n", recvbuf);
*/
	return -1;	
}
#endif

int Read_Line(int fd, char *recvbuf, int len)
{
    int				i,cnt;
    int             restlen, readlen, rtnlen;

    restlen = len;
    readlen = 0;

    for(i=0; i<10; i++)
    {
        if( (rtnlen = read(fd, &recvbuf[readlen], restlen)) < 0 )
        {
            WriteLog(">>> read(recv) Error (%d:%s)\n", errno, strerror(errno));
            return -1;
        }
        
        if( rtnlen == 0 )
        {
            WriteLog(">>> read(recv) socket closed!!\n");
            return -1;
        }

        readlen = readlen + rtnlen;
        restlen = restlen - rtnlen;

        if( restlen == 0 ) return 1;
    }
    
    WriteLog(">>> read(recv) failed retry(%d) left-len(%d/%d)\n", i,restlen,len);
/*
    fprintf(stdout, "Recv_Data -> [%s]\n", recvbuf);
*/
	return -1;	
}

void WriteLog(const char *fmt, ... )
{
	va_list     ap;
	char	buf[256], curdate[32];
	FILE	*fp;

	mkdir("log", 0755);

	memset(curdate, 0x00, sizeof(curdate)); GetCurrentDate(curdate, YYYYMMDDhhmmss);
	memset(buf, 0x00, sizeof(buf)); sprintf(buf, "./log/%.8s", curdate);
	if( (fp = fopen(buf, "a+")) == NULL )
	{
		fprintf(stderr, "file open Error (%d:%s)!!\n", errno, strerror(errno));
		return;
	}

	fprintf(fp, "�� %.2s:%.2s:%.2s[%d] : ", &curdate[8], &curdate[10], &curdate[12], getpid());

    va_start(ap, fmt);
    vfprintf(fp, fmt, ap);
    va_end(ap);

    fflush(fp);
}

void maskingCardNo(char *LoggingMsg)
{
	unsigned int idx=0;
	
	if( 300 > strlen(LoggingMsg) ) return;
	
	if( 0 == memcmp(&LoggingMsg[296], "1000", 4) || 
		0 == memcmp(&LoggingMsg[296], "I000", 4) || 
		0 == memcmp(&LoggingMsg[296], "1300", 4) ||
		0 == memcmp(&LoggingMsg[296], "1400", 4) ||
		0 == memcmp(&LoggingMsg[296], "1500", 4) ||
		0 == memcmp(&LoggingMsg[296], "1010", 4) ||
		0 == memcmp(&LoggingMsg[296], "I010", 4) )
	{
		for(idx=0; idx<strlen(LoggingMsg); idx++)
		{
			if( '=' == LoggingMsg[idx] )
			{
				if( isdigit(LoggingMsg[idx-1]) && isdigit(LoggingMsg[idx-2]) && isdigit(LoggingMsg[idx-3]) && isdigit(LoggingMsg[idx-4]) &&
					isdigit(LoggingMsg[idx-5]) && isdigit(LoggingMsg[idx-6]) && isdigit(LoggingMsg[idx-7]) && isdigit(LoggingMsg[idx-8]) &&
					isdigit(LoggingMsg[idx+1]) && isdigit(LoggingMsg[idx+2]) && isdigit(LoggingMsg[idx+3]) && isdigit(LoggingMsg[idx+4]) )
				{
					memcpy(&LoggingMsg[idx-8], "XXXX", 4);
					memcpy(&LoggingMsg[idx+1], "XXXX", 4);
					break;
				}
			}
		}
	}
	else if( 0 == memcmp(&LoggingMsg[296], "1001", 4) ||
		0 == memcmp(&LoggingMsg[296], "I001", 4) || 
		0 == memcmp(&LoggingMsg[296], "1301", 4) ||
		0 == memcmp(&LoggingMsg[296], "1401", 4) ||
		0 == memcmp(&LoggingMsg[296], "1011", 4) ||
		0 == memcmp(&LoggingMsg[296], "I011", 4) )
	{
		memcpy(&LoggingMsg[391], "XXXX", 4);
		memcpy(&LoggingMsg[399], "XXXX", 4);
	}
	
	return;
}

void GetCurrentDate(char *curdate, int type)
{
	time_t			tmt;
	struct tm		*calptr;

	time(&tmt);
	calptr = (struct tm *)localtime(&tmt);

	switch(type)
	{
		case	YYYYMMDD:
			strftime(curdate, 9, "%Y%m%d", calptr);
			break;
		case	HHMMSS:
			strftime(curdate, 9, "%H%M%S", calptr);
			break;
		case    YYYYMMDDhhmmss:
			strftime(curdate, 16, "%Y%m%d%H%M%S", calptr);
			break;
	}
}
