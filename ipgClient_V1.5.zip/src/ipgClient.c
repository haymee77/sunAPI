#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <signal.h>
#include <errno.h>
#include <unistd.h>
 
#define	true	1
#define	false	0

#define	EXEC_PROCESS	"ipgExec"

#define CHAR_SIZE 16384 

int  ListenSocketOpen(int);
void makeDaemon();

main(int argc, char *argv[])
{
	int			pid;
	int  		socketfd, newsockfd, len, listen_Port;  
	char 		destination_Addr1[16], destination_Addr2[16];
	char		destination_Port1[8],  destination_Port2[8];
	char		service_Name[6];
	struct		sockaddr_in	cli_addr;
	
	if ( argc != 5 )
	{
		printf("	Usage : ipgClient Listen_Port KSNet_Addr KSNet_Port KSPAY \n");
		exit(0);
	}

	if( getenv("IPGCLIENT_PATH") == NULL )
	{
		printf("ERROR: Cannot search IPGCLIENT_PATH in environment list!!\n\n");
		exit(1);
	}

	memset(destination_Addr1, 0x00, sizeof(destination_Addr1)); memset(destination_Port1, 0x00, sizeof(destination_Port1));
	memset(destination_Addr2, 0x00, sizeof(destination_Addr2)); memset(destination_Port2, 0x00, sizeof(destination_Port2));
	memset(service_Name,0X00,sizeof(service_Name));
	
	listen_Port = atoi(argv[1]);

	strcpy(destination_Addr1, argv[2]); 
	strcpy(destination_Port1, argv[3]);
	strcpy(service_Name,argv[4]);	

	if( !(socketfd = ListenSocketOpen(listen_Port)) ) exit(1);

	makeDaemon();
	
	signal(SIGCHLD, SIG_IGN);  
	
	printf("[ipgClient] Start IPG Client using KISA Seedlib...\n");

	len = sizeof(cli_addr);
	 
	while(true)
	{
		if( (newsockfd = accept(socketfd, (struct sockaddr *)&cli_addr, (socklen_t *)&len)) < 0 )
		{
			fprintf(stderr, "[ipgClient] Cannot accept: %s\n", strerror(errno)); 
			continue;
		}
		
		if (IsIgnoredIp((struct sockaddr *)&cli_addr))
		{
			close(newsockfd);
			continue;
		}
	
		if( (pid = fork()) == 0 )
		{
			char	execbuf[1024], sockbuf[5];
 
			close(socketfd);

			memset(execbuf, 0x00, sizeof(execbuf)); sprintf(execbuf, "%s/%s", getenv("IPGCLIENT_PATH"), EXEC_PROCESS);
			memset(sockbuf, 0x00, sizeof(sockbuf)); sprintf(sockbuf, "%d", newsockfd);

			if( execl(execbuf, EXEC_PROCESS, sockbuf, destination_Addr1, destination_Port1, service_Name,  (char *)0) < 0 )
			{
				fprintf(stderr, "[ipgClient] execl fail: %s\n", strerror(errno));
				fprintf(stderr, "execbuf = [%s]\n", execbuf);
				exit(1);
			}
		}
		else
		if( pid < 0 )
		{
			fprintf(stderr, "[ipgClient] fork error: %s\n", strerror(errno));
			exit(1);
		}
		else
			close(newsockfd);
	}
}
	
int ListenSocketOpen(int Port_Num)
{
	int					sockfd;
	struct linger		ling;
	struct sockaddr_in	addr;

	if( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
	{
		printf("Socket Open Error : %s\n", strerror(errno));
		return false;
	}   

	ling.l_onoff  = 1;
	ling.l_linger = 1;
	setsockopt(sockfd, SOL_SOCKET, SO_LINGER, (char*)&ling, sizeof(ling));
	setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, (char*)&Port_Num, sizeof(Port_Num));
 
	bzero(&addr, sizeof(addr));
	addr.sin_family      = AF_INET;
	addr.sin_addr.s_addr = INADDR_ANY;
	addr.sin_port        = htons(Port_Num);

	if( bind(sockfd, (struct sockaddr *)&addr, sizeof(addr)) < 0 )  
	{
		printf("bind Error : %s\n", strerror(errno));
		return false;
	}

	listen(sockfd, 20);

	return sockfd;
}

void makeDaemon() 
{
	pid_t   pid;

	if( (pid = fork()) < 0 )  
	{ 
		printf("MakeDaemon Error : %s\n", strerror(errno));
		exit(1);   
	}
	else if( pid != 0 ) exit(0);

	setsid();

	return;
}

int IsIgnoredIp(struct sockaddr_in *cli_addr)
{
	static int si_x_ip_flag = -1; /* -1 : not-set, 0 : no-count, 1 : set */
	static char ignoreips[256];
	char        *sptr, *cptr ,client_ip[32];

	if (!si_x_ip_flag) return 0;
		
	if (-1 == si_x_ip_flag)
	{
		memset(ignoreips ,0x00 ,sizeof(ignoreips));
		if (!getenv("L4_SWITCH_IPADDR"))
		{
			si_x_ip_flag = 0;
			return 0;
		}else
		{
			sprintf(ignoreips, ",%s,", getenv("L4_SWITCH_IPADDR"));
			si_x_ip_flag = 1;
		}
	}
	
	memset(client_ip ,0x00 ,sizeof(client_ip));
#if 0
	sprintf(client_ip, "%s", inet_ntoa(cli_addr->sin_addr));
#endif
#if 0
	strcpy(client_ip ,inet_ntoa(cli_addr->sin_addr));
#endif
	
	if (!inet_ntop(AF_INET ,&(cli_addr->sin_addr ) ,client_ip ,sizeof(client_ip)))
	{
		printf("inet_ntop Error(%d:%s)\n",errno ,strerror(errno));
		return 0;
	}

	sptr = ignoreips;

	if (!(cptr = strstr(sptr, client_ip))) return 0;

	if (',' == *(sptr + (cptr - sptr) - 1) || ',' == *(cptr + strlen(client_ip))) return 1;
		
	return 0;
}
