/******************************* Type Definitions *****************************/
#ifndef DWORD
#define BYTE	unsigned char		/* 	unsigned 1-byte data type */
#define WORD	unsigned short int	/* 	unsigned 2-bytes data type */
#define DWORD	unsigned int		/* 	unsigned 4-bytes data type */
#endif
/***************************** Endianness Define ******************************/

#ifdef __cplusplus
extern "C" {
#endif
int  GenerateSeedKeyString(unsigned char *);
int  JE_SEED_Encrypt(unsigned char *, BYTE *, DWORD, BYTE *, DWORD *);
int  JE_SEED_Decrypt(unsigned char *, BYTE *, DWORD, BYTE *, DWORD *);
#ifdef __cplusplus
}
#endif

