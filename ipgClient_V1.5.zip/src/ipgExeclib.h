int RecvMsg(int *,char *);
int WriteMsg(int,char *);
int RequestApproval(int, char *, int* ,char *);
int InitialEnv(int, char **);
void WriteLog(const char *fmt, ... );
void maskingCardNo(char *LoggingMsg);
